package com.org.centro8.sistema_banco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaBancoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaBancoApplication.class, args);
	}

}
