package com.org.centro8.sistema_banco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaBancoApplicationTests {

	@Test
	void contextLoads() {
	}

}
