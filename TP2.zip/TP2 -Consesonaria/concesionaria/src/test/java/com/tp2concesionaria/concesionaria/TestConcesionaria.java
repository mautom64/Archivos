package com.tp2concesionaria.concesionaria;

import java.util.ArrayList;

public class TestConcesionaria {

    public static void main(String[] args) {

        // Crear autos y motos
        Vehiculo autoA = new Auto("Peugeot", "206", 200000.00, 4);
        Vehiculo motoA = new Moto("Honda", "Titan", 60000.00, 125);
        Vehiculo autoB = new Auto("Peugeot", "208", 250000.00, 5);
        Vehiculo motoB = new Moto("Yamaha", "YBR", 80500.50, 160);

        // Crear lista
        ListaVehiculos concesionaria = new ListaVehiculos(new ArrayList<>());

        // Agregar todos los vehículos
        concesionaria.agregarVehiculos(autoA, motoA, autoB, motoB);

        // Mostrar listado
        concesionaria.mostrarVehiculos();

        System.out.println("=============================");

        concesionaria.mostrarVehiculoMasCaro();
        concesionaria.mostrarVehiculoMasBarato();
        concesionaria.mostrarVehiculoConLetra("Y");

        System.out.println("=============================");

        concesionaria.ordenarPorPrecioDesc();

        System.out.println("=============================");

        concesionaria.ordenarPorOrdenNatural();
    }
}
