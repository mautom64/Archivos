package com.tp2concesionaria.concesionaria;

import java.util.List;

public interface IConcesionaria {

    // Agrega uno o varios vehículos a la lista
    void agregarVehiculos(Vehiculo... vehiculos);

    // Muestra todos los vehículos en pantalla
    void mostrarVehiculos();

    // Muestra el vehículo más caro
    void mostrarVehiculoMasCaro();

    // Muestra el vehículo más barato
    void mostrarVehiculoMasBarato();

    // Muestra vehículos que contengan una letra específica en el modelo o marca
    void mostrarVehiculoConLetra(String letra);

    // Devuelve la lista ordenada por precio de mayor a menor
    List<Vehiculo> ordenarPorPrecioDesc();

    // Ordena los vehículos según el orden natural (compareTo en Vehiculo)
    void ordenarPorOrdenNatural();
}
