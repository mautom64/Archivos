package com.tp2concesionaria.concesionaria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConcesionariaApplication {

    public static void main(String[] args) {
        SpringApplication.run(ConcesionariaApplication.class, args);
    }

}
