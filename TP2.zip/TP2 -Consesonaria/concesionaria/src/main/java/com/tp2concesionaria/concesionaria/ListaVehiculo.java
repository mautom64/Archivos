package com.tp2concesionaria.concesionaria;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public abstract class ListaVehiculo implements IConcesionaria {

    private List<Vehiculo> vehiculos;

    public ListaVehiculo(List<Vehiculo> vehiculos) {
        this.vehiculos = vehiculos;
    }

    /**
     * Muestra todos los vehículos registrados
     */
    public void imprimirVehiculos() {
        vehiculos.forEach(System.out::println);
    }

    /**
     * Agrega uno o varios vehículos usando varargs
     */
    @Override
    public void agregarVehiculos(Vehiculo... nuevos) {
        vehiculos.addAll(Arrays.asList(nuevos));
    }

    /**
     * Vehículo con el valor más alto
     */
    @Override
    public void vehiculoMasCaro() {
        double precioMaximo = vehiculos.stream()
                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                .get() // <-- lo pediste sin orElse
                .getPrecio();

        vehiculos.stream()
                .filter(v -> v.getPrecio() == precioMaximo)
                .forEach(v -> System.out.println("Vehículo más caro: " + v.getMarca() + " " + v.getModelo()));
    }

    /**
     * Vehículo con el valor más bajo
     */
    @Override
    public void VehiculoMasBarato() {
        double precioMinimo = vehiculos.stream()
                .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                .get() // 
                .getPrecio();

        vehiculos.stream()
                .filter(v -> v.getPrecio() == precioMinimo)
                .forEach(v -> System.out.println("Vehículo más barato: " + v.getMarca() + " " + v.getModelo()));
    }

    /**
     * Busca coincidencias en el modelo
     */
    public void VehiculoConLetra(String texto) {
        vehiculos.stream()
                .filter(v -> v.getModelo().toLowerCase().contains(texto.toLowerCase()))
                .forEach(v -> System.out.println(
                "Vehículo que contiene '" + texto + "': " + v.getMarca() + " " + v.getModelo()
        ));
    }

    /**
     * Muestra los vehículos desde el precio más alto al más bajo
     */
    @Override
    public void <Vehiculo> ordenarPorPrecioDesc() {
        vehiculos.stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                .forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo()));

        return vehiculos;
    }

    /**
     * Orden natural definido por compareTo (marca / modelo / precio)
     */
    @Override
    public void ordenarPorOrdenNatural() {
        Set<Vehiculo> ordenados = new TreeSet<>(vehiculos);
        ordenados.forEach(System.out::println);
    }
}
