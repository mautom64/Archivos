package com.tp2concesionaria.concesionaria;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

@Getter
@Data
@AllArgsConstructor
public abstract class Vehiculo implements Comparable<Vehiculo> {

    private String marca;
    private String modelo;
    private double precio;

    public String getPrecioFormateado() {
        DecimalFormat formato = new DecimalFormat("#,##0.00", new DecimalFormatSymbols(new Locale("es", "AR")));
        return formato.format(precio);
    }

    @Override
    public int compareTo(Vehiculo otroVehiculo) {
        String actual = marca + " " + modelo + " " + precio;
        String comparado = otroVehiculo.marca + " " + otroVehiculo.modelo + " " + otroVehiculo.precio;
        return actual.compareTo(comparado);
    }
}
